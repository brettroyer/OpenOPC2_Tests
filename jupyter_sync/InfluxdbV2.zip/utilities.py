import time


class ExecutionTime:
    """
    This class is used for timing execution of code.

    Example Usage:
    timer = ExecutionTime() #Start the timer
    sample_list = list()
    my_list = [random.randint(1, 888898) for num in
           range(1, 1000000) if num % 2 == 0]
    print('Finished in {} seconds.'.format(timer.duration()))
    """
    def __init__(self):
        self.start_time = time.time()

    def __repr__(self):
        return time.asctime(time.localtime(self.start_time))

    def duration(self) -> float:
        value = time.time() - self.start_time
        return float(f'{value:.2f}')

    def human(self) -> str:
        duration = time.time() - self.start_time
        if duration > 60:
            value = duration/60  # Seconds/Minute
            return f"{value:.2f} minutes"
        elif duration > 3600:
            value = duration/60/60  # Seconds/Minutes/Hours
            return f"{value:.2f} hours"
        else:
            return f"{duration:.2f} seconds"

def list_from_file(filename):
        """
        Create python list from .txt file.

        :param filename = filename.txt or other text input
        :return List = Python List of filename content
         """
        with open(filename, 'r', encoding='utf-8', errors='ignore') as In_File:
            # x = []
            # for line in In_File:
            #     x.append(line.strip().rstrip())
            #
            x = [line.strip().rstrip() for line in In_File]
        return x

